﻿namespace ConsoleGameLibrary.Classes.Weapons
{
    class Dagger : AttackItem
    {
        public override int Damage { get => 20; }
        public override int Range { get => 5; }
        
    }
}
