﻿namespace ConsoleGameLibrary.Classes.Weapons
{
    class Bow : AttackItem
    {
        public override int Damage { get => 25; }
        public override int Range { get => 70; }
    }
}
