﻿namespace ConsoleGameLibrary.Classes.Weapons
{
    class Sword : AttackItem
    {
        public override int Damage { get => 30; }
        public override int Range { get => 10; }
    }
}
