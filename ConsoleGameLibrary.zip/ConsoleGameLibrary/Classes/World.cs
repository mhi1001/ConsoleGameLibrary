﻿using System.Collections.Generic;

namespace ConsoleGameLibrary
{
    public class World
    {
        
        public List<Creature> Creatures { get; set; }
        public int MaxX { get; set; }
        public int MaxY { get; set; }
    }
}
