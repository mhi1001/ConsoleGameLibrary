﻿namespace ConsoleGameLibrary.Classes.Shields
{
    class BucklerShield : DefenseItem
    {
        public override int DamageDefense { get => 50; }
    }
}
