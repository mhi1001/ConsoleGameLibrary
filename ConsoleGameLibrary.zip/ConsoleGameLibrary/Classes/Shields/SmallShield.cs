﻿namespace ConsoleGameLibrary.Classes.Shields
{
    public class SmallShield : DefenseItem
    {
        public override int DamageDefense { get => 20; }
    }
}
