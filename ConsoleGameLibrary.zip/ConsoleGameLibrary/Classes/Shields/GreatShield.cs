﻿namespace ConsoleGameLibrary.Classes.Shields
{
    class GreatShield : DefenseItem
    {
        public override int DamageDefense { get => 90; }
    }
}
